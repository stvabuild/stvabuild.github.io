import dependencies  # noqa, pylint: disable=unused-import
from lib.service import run

run()
