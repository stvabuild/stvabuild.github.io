# -*- coding: utf-8 -*-
#$pyFunction
def GetLSProData(page_data, Cookie_Jar, m):
    items = [('[COLOR orangered][COLOR white]CANALES DE DEPORTES[/COLOR]', 'deportes', 'https://i.imgur.com/ZcG5Wvu.jpg'), ('[COLOR orangered][COLOR white]TV PREMIUM[/COLOR]', 'tvpremium', 'https://i.imgur.com/AhCogTD.jpg'), ('[COLOR orangered][COLOR white]TV INFANTIL[/COLOR]', 'infantil', 'https://i.imgur.com/7iGElA4.jpg'), ('[COLOR orangered][COLOR white]CANALES DE DOCUMENTALES[/COLOR]', 'documentales', 'https://i.imgur.com/hzBiiWJ.jpg'), ('[COLOR orangered][COLOR white]TAQUILLAS[/COLOR]', 'taquilla', 'https://i.imgur.com/gfpSeHc.jpg'), ('[COLOR orangered][COLOR white]LATINOS[/COLOR]', 'latino', 'https://i.imgur.com/8nIpSn3.jpg'), ('[COLOR gold]** [/COLOR][COLOR white]INFORMACION IMPORTANTE[COLOR gold] **[/COLOR]', 'informacion', 'https://i.imgur.com/Z2uD47a.jpg')]
    return items
