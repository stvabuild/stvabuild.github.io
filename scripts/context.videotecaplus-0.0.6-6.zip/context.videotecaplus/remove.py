# -*- coding: utf-8 -*-
#
#     Copyright (C) 2016 VPlus
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#
########## removed:
import os
import glob
import sys
import json
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs

addon = xbmcaddon.Addon()
lang = addon.getLocalizedString

separate_movies = addon.getSetting('separate_movies')
remove_empty = addon.getSetting('remove_empty')

def kodiJsonRequest(params):
	data = json.dumps(params)
	request = xbmc.executeJSONRPC(data)
	try:
		response = json.loads(request)
	except UnicodeDecodeError:
		response = json.loads(request.decode('utf-8', 'ignore'))
	try:
		if 'result' in response:
			return response['result']
		return None
	except KeyError:
		logger.warn("[%s] %s" % (params['method'], response['error']['message']))
		return None

def deleteFile(file):
	if xbmcvfs.exists(file):
		xbmcvfs.delete(file)

def deleteDir(dir):
	xbmcvfs.rmdir(dir,force=True)

def deleteVideo(path, video):
	deleteFile(path + video)
	filebase = path + os.path.splitext(video)[0]
	deleteFile(filebase + ".srt")
	deleteFile(filebase + ".pt.srt")
	deleteFile(filebase + ".en.srt")
	deleteFile(filebase + ".nfo")
	deleteFile(filebase + ".jpg")
	deleteFile(filebase + "-poster.jpg")
	deleteFile(filebase + "-fanart.jpg")
	deleteFile(filebase + "-thumb.jpg")
	deleteFile(filebase + "-banner.jpg")
	deleteFile(filebase + "-thumb.jpg")
	if remove_empty == "true":
		deleteDir(path)

def dltMovie(id, path, video, titulo):
	kodiJsonRequest({'jsonrpc': '2.0', 'method': 'VideoLibrary.RemoveMovie', 'params': {'movieid': int(id)}, 'id': 1})
	if separate_movies == "true":
		xdir, xfil = xbmcvfs.listdir(path)
		for fl in xfil:
			xbmcvfs.delete(path + fl)
		deleteDir(path)
	else:
		deleteVideo(path, video)
	xbmc.executebuiltin('Notification(' + titulo + ',' + "Película borrada" + ')')

def dltEpisode(id, path, video, titulo):
	kodiJsonRequest({'jsonrpc': '2.0', 'method': 'VideoLibrary.RemoveEpisode', 'params': {'episodeid': int(id)}, 'id': 1})
	deleteVideo(path, video)
	xbmc.executebuiltin('Notification(' + titulo + ',' + "Episodio borrado" + ')')

def dltTvShow(id, path, video, titulo):
	kodiJsonRequest({'jsonrpc': '2.0', 'method': 'VideoLibrary.RemoveTVShow', 'params': {'tvshowid': int(id)}, 'id': 1})
	deleteVideo(path, video)
	xbmc.executebuiltin('Notification(' + titulo + ',' + "Serie borrada" + ')')

def dltMusicVideos(id, path, video, titulo):
	kodiJsonRequest({'jsonrpc': '2.0', 'method': 'VideoLibrary.RemoveMusicVideo', 'params': {'musicvideoid': int(id)}, 'id': 1})
	deleteVideo(path, video)
	xbmc.executebuiltin('Notification(' + titulo + ',' + "Vídeo Musical borrado" + ')')

def dltVideos(path, video, titulo):
	deleteVideo(path, video)
	xbmc.executebuiltin('Notification(' + titulo + ',' + "Vídeo borrado" + ')')

def dlt():
	if "videodb" in xbmc.getInfoLabel('ListItem.Path'):
		xbmcgui.Dialog().yes('¡Atención!', "Parece que estás intentando borrar contenido desde un acceso directo, esto puede causar problemas a la hora de borrar, por favor, hazlo desde el apartado de Series o Películas")
	else:
		if xbmcgui.Dialog().yesno("Vas a borrar "+"\'"+xbmc.getInfoLabel('ListItem.Label')+"\'"+ " (Esto no se puede deshacer)"," ¿Estás seguro? "):
			path=xbmc.getInfoLabel('ListItem.Path')
			video = xbmc.getInfoLabel('ListItem.FileName')
			titulo = xbmc.getInfoLabel('ListItem.Label')
			if xbmc.getInfoLabel('Container.Content')=='files':
				dltVideos(path, video, titulo)
			else:
				id=int(xbmc.getInfoLabel('ListItem.DBID'))
				if id<0: id=int(xbmc.getInfoLabel('ListItem.Top250'));
				if id>0:
					dbtype = xbmc.getInfoLabel('ListItem.DBTYPE')
					if dbtype=='movie': dltMovie(id, path, video, titulo)
					elif dbtype=='tvshow': dltTvShow(id, path, video, titulo)
					elif dbtype=='episode': dltEpisode(id, path, video, titulo)
					elif dbtype=='musicvideo': dltMusicVideos(id, path, titulo)

if __name__ == '__main__':
	dlt()
